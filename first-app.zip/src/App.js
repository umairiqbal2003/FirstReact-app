
import './App.css';
import { Bgimage } from './components/Home';

function App() {
  return (
    <>
    <Bgimage/>
    
    </>
  );
}

export default App;
